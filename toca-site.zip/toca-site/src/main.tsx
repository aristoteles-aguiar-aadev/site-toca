import React from 'react';
import { createRoot } from 'react-dom/client';
import { ArrowRight, CalendarCheck, HeartHandshake, MapPin, Menu, Phone, ShieldCheck, Sparkles, Star, UsersRound, X } from 'lucide-react';
import './styles.css';

const contacts = {
  phone: '(85) 3122-0070',
  whatsapp: '(85) 99769-0022',
  instagram: '@EUSOUTOCA',
  waLink: 'https://wa.me/5585997690022',
  igLink: 'https://www.instagram.com/eusoutoca/'
};

const specialties = [
  'Psicologia',
  'Psicopedagogia',
  'Psicomotricidade',
  'Fonoaudiologia',
  'Terapia Ocupacional',
  'Fisioterapia Motora',
  'Fisioterapia Visual',
  'Musicoterapia'
];

const agreements = ['Unimed', 'Abmais Saúde', 'São Camilo', 'Rede Saúde', 'Cafaz', 'ISSEC'];

function App() {
  const [menuOpen, setMenuOpen] = React.useState(false);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  return (
    <main>
      <header className="site-header">
        <a className="brand" href="#top" aria-label="Toca - início">
          <span className="brand-mark">T</span>
          <span>Toca</span>
        </a>

        <nav className={menuOpen ? 'nav open' : 'nav'} aria-label="Menu principal">
          <button onClick={() => scrollTo('especialidades')}>Especialidades</button>
          <button onClick={() => scrollTo('convenios')}>Convênios</button>
          <button onClick={() => scrollTo('contato')}>Contato</button>
          <a className="nav-cta" href={contacts.waLink} target="_blank" rel="noreferrer">Agendar avaliação</a>
        </nav>

        <button className="menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Abrir menu">
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </header>

      <section id="top" className="hero-section">
        <div className="hero-copy">
          <p className="eyebrow"><Sparkles size={16} /> Equipe de desenvolvimento infantil</p>
          <h1>Um lugar onde cada avanço da criança é visto de perto.</h1>
          <p className="hero-text">
            A Toca reúne cuidado multidisciplinar, escuta ativa e rotina terapêutica pensada para crianças e famílias que precisam de acompanhamento com presença, carinho e técnica.
          </p>
          <div className="hero-actions">
            <a className="primary-button" href={contacts.waLink} target="_blank" rel="noreferrer">
              Agendar pelo WhatsApp <ArrowRight size={18} />
            </a>
            <button className="secondary-button" onClick={() => scrollTo('especialidades')}>Ver especialidades</button>
          </div>
          <div className="trust-row" aria-label="Diferenciais da Toca">
            <span><HeartHandshake size={17} /> Acolhimento familiar</span>
            <span><UsersRound size={17} /> Equipe integrada</span>
            <span><ShieldCheck size={17} /> Atendimento especializado</span>
          </div>
        </div>

        <div className="hero-card" aria-label="Imagem institucional da Toca">
          <div className="photo-shell">
            <img src="/assets/convenios-toca.jpeg" alt="Atendimento infantil na Toca" />
          </div>
          <div className="floating-note note-one">Convênios que atendemos</div>
          <div className="floating-note note-two">Cuidado no tempo da criança</div>
        </div>
      </section>

      <section className="section intro-section">
        <div className="section-label">Jeito Toca</div>
        <h2>Menos clínica fria. Mais presença, rotina e vínculo.</h2>
        <p>
          O site foi pensado para fugir da estética genérica: cores vindas das peças reais da Toca, imagens próprias, textos diretos e uma navegação simples, com aparência premium e humana.
        </p>
      </section>

      <section id="especialidades" className="section specialties-section">
        <div className="section-heading">
          <div>
            <div className="section-label">Especialidades</div>
            <h2>Cuidado convencional e especializado.</h2>
          </div>
          <a href={contacts.igLink} target="_blank" rel="noreferrer" className="text-link">Ver Instagram</a>
        </div>

        <div className="specialty-grid">
          {specialties.map((item, index) => (
            <article className="specialty-card" key={item}>
              <span className="card-index">{String(index + 1).padStart(2, '0')}</span>
              <h3>{item}</h3>
              <p>Atendimento com olhar integrado ao desenvolvimento infantil e à rotina da família.</p>
            </article>
          ))}
        </div>
      </section>

      <section id="convenios" className="section agreements-section">
        <div className="agreements-copy">
          <div className="section-label">Convênios</div>
          <h2>A Toca atende por diferentes convênios.</h2>
          <p>Consulte a disponibilidade para avaliação, especialidade, autorização e agenda antes do atendimento.</p>
          <div className="agreement-list">
            {agreements.map((item) => <span key={item}>{item}</span>)}
          </div>
        </div>
        <div className="image-stack">
          <img src="/assets/toca-especialidade.png" alt="Lista de especialidades da Toca" />
          <img src="/assets/contato-toca.png" alt="Informações de contato da Toca" />
        </div>
      </section>

      <section className="section process-section">
        <div className="section-label">Como funciona</div>
        <h2>Da primeira conversa ao plano terapêutico.</h2>
        <div className="process-grid">
          <article><CalendarCheck /><h3>1. Agendamento</h3><p>Contato inicial pelo WhatsApp para entender a necessidade da família.</p></article>
          <article><Star /><h3>2. Avaliação</h3><p>Observação cuidadosa da criança e definição do melhor caminho terapêutico.</p></article>
          <article><HeartHandshake /><h3>3. Acompanhamento</h3><p>Plano com equipe integrada, evolução acompanhada e orientação para a família.</p></article>
        </div>
      </section>

      <section id="contato" className="contact-section">
        <div>
          <div className="section-label">Contato</div>
          <h2>Vamos conversar sobre o desenvolvimento da sua criança?</h2>
          <p>Fale com a Toca e consulte a melhor agenda para avaliação.</p>
        </div>
        <div className="contact-card">
          <a href={`tel:${contacts.phone.replace(/\D/g, '')}`}><Phone size={19} /> {contacts.phone}</a>
          <a href={contacts.waLink} target="_blank" rel="noreferrer"><Phone size={19} /> {contacts.whatsapp}</a>
          <a href={contacts.igLink} target="_blank" rel="noreferrer"><MapPin size={19} /> {contacts.instagram}</a>
        </div>
      </section>

      <footer>
        <span>Toca — Equipe de Desenvolvimento Infantil</span>
        <a href={contacts.igLink} target="_blank" rel="noreferrer">Instagram {contacts.instagram}</a>
      </footer>
    </main>
  );
}

export default App;
